# cache/__init__.py
"""
Cache module for storing and retrieving contest data locally.
"""